<!-- ZROBIONE -->
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Portal samochodowy</title>
</head>
<body>
    <header>
        <h1><a href="main.php" class="a">Portal samochodowy</a></h1>
    </header>
    <br><br><br><br><br>
    <h3>Użytkownicy</h3>
    <br>
    <table>
    <?php
    session_start();
    class dbInfo
    {
        private $host;
        private $user;
        private $password;
        private $dbname;
        public function getDB($host, $user, $password, $dbname)
        {
            $this->host = $host;
            $this->user = $user;
            $this->password = $password;
            $this->dbname = $dbname;
        }
        public function dbConnect()
        {
            try
            {
                $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                // echo "Połączenie udane";
                return $conn;
            }catch(PDOException $e)
            {
            echo "Błąd połączenia: " . $e->getMessage();
            }
        }
    }

        $db = new dbInfo();
        $db->getDB("localhost", "root", "", "cars");
        $conn = $db->dbConnect();
        //$query= mysqli_query($conn, "SELECT `id`, `imie`, `nazwisko`, `login` FROM users;");
        $stmt = $conn->prepare("SELECT `id`, `imie`, `nazwisko`, `login` FROM users");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <table>
        <?php
        foreach($results as $row){
            ?>
                 <tr>
                    <td> <?php echo $row['id'] ?> </td>
                    <td> <?php echo $row['imie'] ?> </td>
                    <td> <?php echo $row['nazwisko'] ?> </td>
                    <td> <?php echo $row['login'] ?> </td>
                    <td>
                    <form action='edit.php' method='POST'>
                        <input type='hidden' name='id' value='<?php echo $row['id'] ?>'>
                        <input type='hidden' name='imie' value='<?php echo $row['imie'] ?>'>
                        <input type='hidden' name='nazwisko' value='<?php echo $row['nazwisko'] ?>'>
                        <input type='hidden' name='login' value=' <?php echo $row['login'] ?>'>
                        <div class="modifyBtn"><button type='submit' class="btn btn-outline-primary">Edytuj</button></div>
                    </form>
                    </td>
                    <td>
                    <form method ="post" action="delete.php">
                        <input type='hidden' name='id' value='<?php echo $row['id'] ?>'>
                        <div class="modifyBtn"><button type='submit' class="btn btn-outline-primary">Usuń</button></div>
                    </form>
                    </td>
                </tr>
            <?php
        }
    ?>
    </table>
    
</body>
</html>