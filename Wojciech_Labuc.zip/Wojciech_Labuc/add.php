<?php
//ZROBIONE

class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
        {
        echo "Błąd połączenia: " . $e->getMessage();
        }
    }
}
    $db = new dbInfo();
    $db->getDB("localhost", "root", "", "cars");
    $conn = $db->dbConnect();
    $mark = $_POST['mark'];
    $model = $_POST['model'];
    $price = $_POST['price'];
    $opis = $_POST['opis'];
    //$image = $_POST['image'];
    $car_image = "";
        if (isset($_FILES['image'])) {
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $fileCount = count($_FILES['image']['name']);
            for ($i=0; $i < $fileCount; $i++) { 

                $file_extension = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION));

                if (in_array($file_extension, $allowed_extensions)) {
                    $target = "img/";
                    $file_name = uniqid() . "." . $file_extension;
                    $target_file = $target . $file_name;
                    if (move_uploaded_file($_FILES['image']['tmp_name'][$i], $target_file)) {
                        $car_image .= $file_name . '/'; 
                    } else {
                        echo "Błąd przy przesyłaniu zdjęcia" . $_FILES['image']['name'][$i];
                    }
                } else {
                    echo "Niedozwolone rozszerzenie pliku.";
                }
            }
        }
    $stmt = $conn->prepare("INSERT INTO `ogloszenia`(`Marka`, `Model`, `Cena`, `Zdjecie`, `Opis`) VALUES ('$mark', '$model', '$price', '$car_image', '$opis')");
    $stmt->execute();
    header("location: ogloszenia.php");
?>