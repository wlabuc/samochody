<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Portal samochodowy</title>
</head>
<body>
    <header>
        <h1><a href="main.php" class="a">Portal samochodowy</a></h1>
    </header>
        <br><br><br><br><br>
        <?php
            $id = $_POST['id'];
            $imie = $_POST['imie'];
            $nazwisko = $_POST['nazwisko'];
            $login = $_POST['login'];
        ?>
        <form action="edit.php" method="post" class="forms">
            <input type = "hidden" name="id" value = "<?php echo $id;?>">   
            imie: <br><input type="text" name="imie" value="<?php echo $imie; ?>"><br>
            nazwisko: <br><input type="text" name="nazwisko" value="<?php echo $nazwisko; ?>" required><br>
            email: <br><input type="text" name="login" value="<?php echo $login; ?>" required><br><br>
            <button type="submit" name = "btn-cont" class="btn btn-primary">Zmień</button>
        </form>
        <?php
           
           class dbInfo
           {
               private $host;
               private $user;
               private $password;
               private $dbname;
               public function getDB($host, $user, $password, $dbname)
               {
                   $this->host = $host;
                   $this->user = $user;
                   $this->password = $password;
                   $this->dbname = $dbname;
               }
               public function dbConnect()
               {
                   try
                   {
                       $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
                       $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                       // echo "Połączenie udane";
                       return $conn;
                   }catch(PDOException $e)
                   {
                   echo "Błąd połączenia: " . $e->getMessage();
                   }
               }
           }
       
               $db = new dbInfo();
               $db->getDB("localhost", "root", "", "cars");
               $conn = $db->dbConnect();
            if(isset($_POST['btn-cont']))
            {
                if(!empty($imie) && !empty($nazwisko) && !empty($login))
                {
                    $stmt = $conn->prepare("UPDATE `users` SET `imie`='$imie',`nazwisko`='$nazwisko',`login`='$login' WHERE id = '$id'");
                    $stmt->execute();
                    echo "Zaktualizowano dane";
                }
                else
                    echo "Uzupełnij wszystkie pola!.";
            }
        ?>
</body>
</html>