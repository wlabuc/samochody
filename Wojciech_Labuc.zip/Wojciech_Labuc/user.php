<?php
//ZROBIONE
class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
        {
        echo "Błąd połączenia: " . $e->getMessage();
        }
    }
}

    $db = new dbInfo();
    $db->getDB("localhost", "root", "", "cars");
    $conn = $db->dbConnect();
$name = $_POST['name'];
$lastname = $_POST['lastname'];
$login = $_POST['login'];
$pattern2 = '/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/';
$pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/';
if(preg_match($pattern, $_POST['password']))
{
    $password = md5($_POST['password']);
    if(preg_match($pattern2, $login))
    {
        $stmt = $conn->prepare("SELECT `login`, `haslo` FROM `users` WHERE `login` = '$login';");
        $stmt->execute();
        $num_of_rows = $stmt->fetchColumn();
        if($num_of_rows == 0)   
        {
            $stmt = $conn->prepare("INSERT INTO `users`(`imie`, `nazwisko`, `login`, `haslo`) VALUES ('$name', '$lastname', '$login', '$password')");
            $stmt->execute();
            header("location: main.php");
            exit();
        }
        else
        {
            echo "Użytkownik o podanym loginie już istnieje!";
        }
    }
    else
        echo "Nieprawidłowy email!";
}
else
    echo "Hasło powinno zawierać conajmniej 8 znaków, jedną wielką i małą literę oraz jedną cyfrę ";
?>