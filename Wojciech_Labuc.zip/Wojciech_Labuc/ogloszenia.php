<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Portal samochodowy</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <header>
        <h1><a href="main.php" class="a">Portal samochodowy</a></h1>
    </header>
    <br><br><br><br>
    <h3>Dodaj nowe ogłoszenie</h3>
    <form method="post" action="add.php" enctype="multipart/form-data">
        Marka<br><input name="mark" required><br>
        Model<br><input name="model" required><br>
        Cena<br><input type="number" name="price" required><br>
        Zdjęcie<br><input type="file" name="image[]" multiple><br>
        Opis<br><textarea rows="5" cols="40" name="opis" required></textarea><br>
        <button type="submit" class="btn btn-outline-primary">Dodaj</button>
    </form>
    <br>
    <h3>Ogłoszenia</h3>
    <?php
         class dbInfo
         {
             private $host;
             private $user;
             private $password;
             private $dbname;
             public function getDB($host, $user, $password, $dbname)
             {
                 $this->host = $host;
                 $this->user = $user;
                 $this->password = $password;
                 $this->dbname = $dbname;
             }
             public function dbConnect()
             {
                 try
                 {
                     $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
                     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                     // echo "Połączenie udane";
                     return $conn;
                 }catch(PDOException $e)
                 {
                 echo "Błąd połączenia: " . $e->getMessage();
                 }
             }
         }
             $db = new dbInfo();
             $db->getDB("localhost", "root", "", "cars");
             $conn = $db->dbConnect();
             $stmt = $conn->prepare("SELECT `id`, `Marka`, `Model`, `Cena`, `Zdjecie`, `Opis` FROM ogloszenia");
             $stmt->execute();
             $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
             ?>
            
                <?php
             foreach($results as $row){
                      ?>
            <section id="cars">
            <p><b>Marka/Model:</b> <?php echo $row['Marka']; ?>/<?php echo $row['Model']; ?></p>
            <p class="description"><?php echo $row['Opis']; ?></p>
            <p><b>Cena:</b> <?php echo $row['Cena'] . ' PLN'; ?></p>
            <?php 
            $photosrc = $row['Zdjecie'];
            $photos = array_filter(explode('/', $photosrc)); // Rozbicie zdjęć na tablicę
            $fileCount = count($photos);

            if (!empty($photos)) { ?>
                <div style="width:40%; margin:0 auto;" id="carousel-<?php echo $row['id']; ?>" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php foreach ($photos as $index => $photo) { ?>
                            <div class="carousel-item <?php echo $index == 0 ? 'active' : ''; ?>">
                                <img src="img/<?php echo $photo; ?>" class="d-block w-100" alt="Zdjęcie samochodu">
                            </div>
                        <?php } ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carousel-<?php echo $row['id']; ?>" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Poprzednie</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carousel-<?php echo $row['id']; ?>" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Następne</span>
                    </button>
                </div>
            <?php } ?>

        </section>
                    <?php
             }
         ?>
</body>
</html>