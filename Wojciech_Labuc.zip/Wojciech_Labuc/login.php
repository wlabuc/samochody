<?php
    session_start();
    $login = $_POST['login'];
    $password2 = md5($_POST['password']);
    class dbInfo
    {
        private $host;
        private $user;
        private $password;
        private $dbname;
        public function getDB($host, $user, $password, $dbname)
        {
            $this->host = $host;
            $this->user = $user;
            $this->password = $password;
            $this->dbname = $dbname;
        }
        public function dbConnect()
        {
            try
            {
                $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                // echo "Połączenie udane";
                return $conn;
            }catch(PDOException $e)
            {
            echo "Błąd połączenia: " . $e->getMessage();
            }
        }
    }

        $db = new dbInfo();
        $db->getDB("localhost", "root", "", "cars");
        $conn = $db->dbConnect();
    $stmt = $conn->prepare("SELECT `id`,`login`, `haslo` FROM `users` WHERE `login` = '$login' AND `haslo` = '$password2';");
    $stmt->execute();
    $num_of_rows = $stmt->fetchColumn();
    echo $num_of_rows;
    if($num_of_rows > 0)
    {
        echo "Zalogowano";
        $_SESSION['login'] = $login;
        header("location: main.php");
        exit();
    }
    else
        echo "Nieprawidłowe dane";
?>